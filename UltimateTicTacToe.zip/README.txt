Change the variable "FireBaseLink" inside the "java/com/example/ultimate_tic_tac_toe/Repository.java" to your Firebase link.


In your Firebase, you need to have the Authentication, and choose the Email/Password option inside the “Native providers”.
Now, inside your app, you need to go to the upper bar, select Tools -> Firebase, and you will have a screen pop up on the right side of your screen. 
You will need to click on Authentication -> Authentication using a custom authentication system, and you will have to click on Connect your app to Firebase and connect your own Firebase.


Also, you need to have the Realtime Database. 
And the link that will be shown to you will be the link to put inside the FireBaseLink.
