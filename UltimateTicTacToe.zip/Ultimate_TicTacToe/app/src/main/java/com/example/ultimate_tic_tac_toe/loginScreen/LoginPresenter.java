package com.example.ultimate_tic_tac_toe.loginScreen;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.example.ultimate_tic_tac_toe.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;


public class LoginPresenter {
    LoginActivity view;
    private FirebaseAuth mAuth;

    public LoginPresenter(LoginActivity view){
        this.view = view;
        mAuth = FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser()!=null){
            view.goToHome();
        }
    }


    public void checkLogin(String gmail, String password) {

        if (gmail.isEmpty() || password.isEmpty()) {
            return;
        }
        mAuth.signInWithEmailAndPassword(gmail, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Successfully signed in, navigate to home screen
                            view.resetEditText();
                            view.goToHome();
                        }
                    }
                });
    }



}
