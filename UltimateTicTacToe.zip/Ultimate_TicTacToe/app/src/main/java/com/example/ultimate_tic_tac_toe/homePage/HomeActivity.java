package com.example.ultimate_tic_tac_toe.homePage;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.joinDialog.CustomDialog;
import com.example.ultimate_tic_tac_toe.joinDialog.IDialog;

import com.example.ultimate_tic_tac_toe.loginScreen.LoginActivity;
import com.example.ultimate_tic_tac_toe.model.User;
import com.example.ultimate_tic_tac_toe.showGames.ShowGamesActivity;
import com.example.ultimate_tic_tac_toe.waitingRoom.WaitingActivity;
import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity implements IDialog {

    HomePresenter presenter;
    int codeEntered;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

            }
        });

        presenter = new HomePresenter(this);
    }

    public void goToCreateGame(View view) {
        Intent intent = new Intent(this, WaitingActivity.class);
        intent.putExtra("requestCode", 1);
        startActivityForResult(intent, 1);
    }

    public void goToJoinGame(View view) {
        CustomDialog cd = new CustomDialog(this);
        cd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        cd.show();

    }

    public void goToHistoryPage(View view) {
        Intent intent = new Intent(this, ShowGamesActivity.class);
        intent.putExtra("requestCode", 1);
        startActivityForResult(intent, 1);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       /* if(resultCode == 3){
            int gameCode = Integer.parseInt(data.getStringExtra("gameCode"));


            presenter.removeRunningGame(gameCode);


        }*/

    }

    public void getCode(int code){
        codeEntered = code;
        presenter.clickedOnJoinGame(codeEntered);
    }



    public void signOut(View view) {
        FirebaseAuth.getInstance().signOut();
        setResult(RESULT_CANCELED, new Intent(this, LoginActivity.class));
        finish();
    }

    public void switchToGameActivity(int enteredCode) {
        Intent intent = new Intent(this, WaitingActivity.class);
        intent.putExtra("requestCode", enteredCode);
        startActivityForResult(intent,0);
    }

    public void setUserImg(User user) {
        TextView textView = findViewById(R.id.username_tv_home);
        textView.setText("Hello " + user.getUsername() +"!");
        ImageView imageView = findViewById(R.id.profile_img_home);
        imageView.setImageBitmap(Repository.getInstance().convertBase64ToBitmap(user.getPicture()));
    }
}