package com.example.ultimate_tic_tac_toe.homePage;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;


import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.example.ultimate_tic_tac_toe.waitingRoom.WaitingActivity;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class HomePresenter implements Repository.LoadRunningGamesListener, Repository.LoadUserListener {
    HomeActivity view;

    ArrayList<RunningGame> allRunningGames;

    RunningGame runningGame;

    User currentUser;

    int enteredCode;

    int checkCode;
    public HomePresenter(HomeActivity view){
        this.view = view;
        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());

    }


    public void clickedOnJoinGame(int code){

        checkCode = 1;

        enteredCode = code;


        Repository.getInstance().setRunningGamesListener(this);
        Repository.getInstance().readRunningGames();


    }

    @Override
    public void getRunningGames(ArrayList<RunningGame> runningGames) {
        allRunningGames = runningGames;

        for (int i = 0; i < runningGames.size(); i++) {
            if(runningGames.get(i).getGameCode() == enteredCode && runningGames.get(i).getStatus() == 1){
                this.runningGame = runningGames.get(i);
                runningGame.setStatus(2);
                runningGame.setPlayer2(currentUser.getUsername());
                runningGame.setPlayer2_img(currentUser.getPicture());
                Repository.getInstance().addRunningGame(runningGame);
                view.switchToGameActivity(enteredCode);
            }

        }

    }


    @Override
    public void getUser(User user) {
        currentUser = user;
        view.setUserImg(user);
    }


    /*public void removeRunningGame(int gameCode) {
        Log.d("test", "HomePresenter: removeRunningGame(): Game " + gameCode + " removed.");

        Repository.getInstance().removeRunningGame(gameCode);
    }*/
}
