package com.example.ultimate_tic_tac_toe.loginScreen;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.homePage.HomeActivity;

public class SignUpActivity extends AppCompatActivity {

    SignUpPresenter presenter;

    EditText gmail;
    EditText username;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_up);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        presenter = new SignUpPresenter(this);

        gmail = findViewById(R.id.geditT_b_signUp);
        username = findViewById(R.id.ueditT_b_signUp);
        password = findViewById(R.id.peditT_b_signUp);
    }

    public void GoBack(View view) {
        setResult(RESULT_CANCELED, new Intent(this, LoginActivity.class));
        finish();
    }

    public void SignUp(View view) {
        presenter.checkSignUp(gmail.getText().toString() ,username.getText().toString(), password.getText().toString());
    }

    public void SignUpWorked(){
        setResult(RESULT_OK, new Intent(this, LoginActivity.class));
        finish();
    }

    public void addImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*"); // Filter to show only images
        startActivityForResult(intent, 0);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData(); // Get the URI of the selected image
            try {
                ImageView imageView = findViewById(R.id.imageView4);
                // Set the selected image to ImageView
                imageView.setImageURI(selectedImageUri);
                presenter.setBitmap(selectedImageUri);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show();
            }
        }
    }
}