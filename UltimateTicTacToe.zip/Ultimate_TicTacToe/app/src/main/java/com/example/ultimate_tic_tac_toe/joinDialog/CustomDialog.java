package com.example.ultimate_tic_tac_toe.joinDialog;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.ultimate_tic_tac_toe.R;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class CustomDialog extends Dialog implements View.OnClickListener {

    public IDialog context;
    public Button button;
    public EditText editText;



    public CustomDialog(@NonNull IDialog context) {
        super((AppCompatActivity)context);
        this.context = context;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_code_dialog);

        button = findViewById(R.id.button);
        editText = findViewById(R.id.editTextNumber);
        button.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        String s = editText.getText().toString();

        if(!s.isEmpty() && s.length() == 6){

            context.getCode(Integer.parseInt(s));
        }


        dismiss();
    }
}
