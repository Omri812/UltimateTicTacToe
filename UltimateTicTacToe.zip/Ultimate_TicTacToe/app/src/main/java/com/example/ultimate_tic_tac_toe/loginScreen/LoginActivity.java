package com.example.ultimate_tic_tac_toe.loginScreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.homePage.HomeActivity;

public class LoginActivity extends AppCompatActivity {

    LoginPresenter presenter;
    EditText gmail;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        gmail = findViewById(R.id.GeditT_b_login);
        password = findViewById(R.id.PeditT_b_login);

        presenter = new LoginPresenter(this);




    }
    public void Login(View view){
        presenter.checkLogin(gmail.getText().toString(), password.getText().toString());
    }

    public void SignUp(View view) {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivityForResult(intent,1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK){
            goToHome();
        }

    }

    public void goToHome(){

        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }
    public void resetEditText() {
        gmail.getText().clear();
        password.getText().clear();
    }




}