package com.example.ultimate_tic_tac_toe.endScreen;

import android.content.Intent;
import android.util.Log;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.mainBoard.MainBoardActivity;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.auth.FirebaseAuth;

public class EndPresenter implements Repository.LoadRunningGameListener, Repository.LoadUserListener {
    EndActivity view;

    RunningGame currentRunningGame;

    User currentUser;

    int gameCode;

    public EndPresenter(EndActivity view, int gameCode){
        this.view = view;

        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());

        Repository.getInstance().setRunningGameListener(this);
        currentRunningGame = Repository.getInstance().getCurrentRunningGame();
        view.updateBoard(currentRunningGame);
    }


    @Override
    public void getRunningGame(RunningGame runningGame) {
        currentRunningGame = runningGame;
        gameCode = runningGame.getGameCode();
    }

    @Override
    public void getUser(User user) {
        currentUser = user;
    }

    public String getCurrentUserName() {
        return currentUser.getUsername();
    }

    public RunningGame getCurrentRunningGame() {
        return currentRunningGame;
    }

    public void updateUser(GameHistory gameHistory) {
        currentUser.addGameHistory(gameHistory);

        currentUser.addGame();

        int whoWon = currentRunningGame.checkFullBoardWinner();

        if(whoWon == 1 && currentUser.getUsername().equals(currentRunningGame.getPlayer1()) ||
                whoWon == 2 && currentUser.getUsername().equals(currentRunningGame.getPlayer2())
            ){
            currentUser.addWin();
        }
        Repository.getInstance().addUser(currentUser);
    }


    public void removeRunningGame() {

        Repository.getInstance().removeRunningGame(currentRunningGame.getGameCode());
    }

}
