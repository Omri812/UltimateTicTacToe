package com.example.ultimate_tic_tac_toe.resignDialog;

public interface IResignDialog {
    void onDialogYes();
    void onDialogNo();
}
