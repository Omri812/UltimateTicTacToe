package com.example.ultimate_tic_tac_toe.waitingRoom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.homePage.HomeActivity;
import com.example.ultimate_tic_tac_toe.mainBoard.MainBoardActivity;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.database.core.Repo;

public class WaitingActivity extends AppCompatActivity {

    WaitingPresenter presenter;
    int requestCode;
    Boolean isLeader;
    TextView gameCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_waiting);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        gameCode = findViewById(R.id.code_tv_waiting);


        requestCode = getIntent().getIntExtra("requestCode", 0) ;


        isLeader = (requestCode == 1);


        presenter = new WaitingPresenter(this, isLeader);


        if (requestCode != 1) {
            updateCode(requestCode+"");
            presenter.setGameCode(requestCode);
        }


        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

                presenter.setCancelResult();

                /*Intent intent = new Intent(WaitingActivity.this, HomeActivity.class);
                intent.putExtra("gameCode", gameCode.getText().toString());

                setResult(3, intent); // 3 for cancelling from waiting room, so it wont make an error if I come back from history
                finish();*/
            }
        });

    }



    public void switchToGameActivity() {
        Intent intent = new Intent(this, MainBoardActivity.class);
        intent.putExtra("gameCode", gameCode.getText().toString());
        startActivityForResult(intent,0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            setResult(RESULT_OK, new Intent(this, HomeActivity.class));
            finish();
        }

    }
    public void updateCode(String code){
        gameCode.setText(code);
    }

    public void updatePlayer2Text(RunningGame runningGame){
        TextView player2Text = findViewById(R.id.Wait_tv_waiting);
        TextView player1Text = findViewById(R.id.player1_tv_wating);
        player2Text.setText(runningGame.getPlayer2());
        player1Text.setText(runningGame.getPlayer1());

        ImageView imageView1 = findViewById(R.id.player1_img_waiting);
        imageView1.setImageBitmap(Repository.getInstance().convertBase64ToBitmap(runningGame.getPlayer1_img()));
        ImageView imageView2 = findViewById(R.id.player2_img_waiting);
        imageView2.setImageBitmap(Repository.getInstance().convertBase64ToBitmap(runningGame.getPlayer2_img()));
    }

    public void setButtonNotVisible(){
        Button button = findViewById(R.id.start_btn_waiting);
        button.setVisibility(View.GONE);
    }

    public void updatePlayer1Text(String name, String picture){
        ImageView imageView = findViewById(R.id.player1_img_waiting);
        imageView.setImageBitmap(Repository.getInstance().convertBase64ToBitmap(picture));

        TextView player1Text = findViewById(R.id.player1_tv_wating);
        player1Text.setText(name);
    }

    public void startGame(View view) {
        presenter.clickedOnStartGame();
    }

    public void gameRemoved() {
        Intent intent = new Intent(this, HomeActivity.class);
        setResult(RESULT_OK, intent);
        finish();

    }

    public void backToHomePage() {
        Intent intent = new Intent(this, HomeActivity.class);
        setResult(RESULT_OK, intent);
        finish();
    }

    public void updateLobby() {
        TextView player2Text = findViewById(R.id.Wait_tv_waiting);
        player2Text.setText("Waiting for Player-2 to join");

        ImageView imageView2 = findViewById(R.id.player2_img_waiting);
        imageView2.setImageResource(R.drawable.nothing);
    }

    public void clickOnGoBack(View view) {
        presenter.setCancelResult();
    }
}