package com.example.ultimate_tic_tac_toe.resignScreen;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.mainBoard.MainBoardActivity;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.RunningGame;

import java.util.Objects;

public class ResignScreenActivity extends AppCompatActivity {


    private ResignScreenPresenter presenter;

    String winner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resign_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        winner = getIntent().getStringExtra("wonByResign");

        presenter = new ResignScreenPresenter(this);

    }

    public void updateBoard(RunningGame currentRunningGame) {

        ImageView image = findViewById(R.id.image_resign);
        TextView whoWon = findViewById(R.id.who_won_resign);
        TextView textView = findViewById(R.id.tv_resign);

        String currentUser = presenter.getCurrentUserName();


        if(winner.equals(currentUser)){

            whoWon.setText("You Won!");
            textView.setText("Good job bro, you won");
            image.setImageResource(R.drawable.great_job);


        }
        else{
            whoWon.setText(winner + " Won!");
            textView.setText("Imagine loosing in TicTacToe");
            image.setImageResource(R.drawable.bozo_logo);

        }

        
    }

    public void backToHome(View view) {

        addGameToHistory();
        presenter.removeRunningGame();
        Intent intent = new Intent(this, MainBoardActivity.class);
        setResult(RESULT_OK, intent);
        finish();

    }

    public void addGameToHistory() {

        GameHistory gameHistory;

        String username = presenter.getCurrentUserName();
        String player1 = presenter.getCurrentRunningGame().getPlayer1();
        String player2 = presenter.getCurrentRunningGame().getPlayer2();
        String player1Status;
        String player2Status;


        player1Status = Objects.equals(winner, player1) ? "won" : "lost";
        player2Status = Objects.equals(winner, player2) ? "won" : "lost";



        if(username.equals(player1)){
            gameHistory = new GameHistory(player1, player2, player1Status,  player2Status);
        }
        else{
            gameHistory = new GameHistory(player2, player1, player2Status,  player1Status);
        }

        presenter.addGameToUser(winner);

        presenter.updateUser(gameHistory);
    }
}