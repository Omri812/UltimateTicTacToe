package com.example.ultimate_tic_tac_toe.model;

import java.util.ArrayList;
import java.util.List;

public class RunningGame {

    int gameCode;
    String player1;
    String player2;
        int status; // status 1 (default) = no player2; 2 = player2 joined; 3 = the game is running; 4 = the game ended;
    int whichPlayerPlaying; // 1 = player1 is playing; 2 = player2 is playing;
    int prevClickedPlace = 4;



    String player1_img;
    String player2_img;

    private ArrayList<ArrayList<Integer>> fullBoard;

    private static final List<List<Integer>> WINNING_POSITIONS = List.of(
            List.of(0, 1, 2), List.of(3, 4, 5), List.of(6, 7, 8), // Rows
            List.of(0, 3, 6), List.of(1, 4, 7), List.of(2, 5, 8), // Columns
            List.of(0, 4, 8), List.of(2, 4, 6)  // Diagonals
    );

    public RunningGame() {
    }

    public RunningGame(String player1, int gameCode, String player1_img) {
        this.player1 = player1;
        status = 1;
        whichPlayerPlaying = 1;
        this.gameCode = gameCode;
        initializeBoard();
        this.player1_img = player1_img;

    }

    private void initializeBoard() {
        fullBoard = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ArrayList<Integer> smallBoard = new ArrayList<>();
            for (int j = 0; j < 9; j++) {
                smallBoard.add(0);
            }
            fullBoard.add(smallBoard);
        }
    }
    public String getPlayer1_img() {
        return player1_img;
    }

    public void setPlayer1_img(String player1_img) {
        this.player1_img = player1_img;
    }

    public String getPlayer2_img() {
        return player2_img;
    }

    public void setPlayer2_img(String player2_img) {
        this.player2_img = player2_img;
    }

    public int getGameCode() {
        return gameCode;
    }

    public void setGameCode(int gameCode) {
        this.gameCode = gameCode;
    }

    public String getPlayer1() {
        return player1;
    }

    public void setPlayer1(String player1) {
        this.player1 = player1;
    }

    public String getPlayer2() {
        return player2;
    }

    public void setPlayer2(String player2) {
        this.player2 = player2;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getWhichPlayerPlaying() {
        return whichPlayerPlaying;
    }

    public void setWhichPlayerPlaying(int whichPlayerPlaying) {
        this.whichPlayerPlaying = whichPlayerPlaying;
    }

    public ArrayList<ArrayList<Integer>> getFullBoard() {
        return fullBoard;
    }

    public void setFullBoard(ArrayList<ArrayList<Integer>> fullBoard) {
        this.fullBoard = fullBoard;
    }

    public int getPrevClickedPlace() {
        return prevClickedPlace;
    }

    public void setPrevClickedPlace(int prevClickedPlace) {
        this.prevClickedPlace = prevClickedPlace;
    }



    public Boolean checkClickedPlace(int square , int place , int player){
        if(fullBoard.get(square).get(place) == 0){
            fullBoard.get(square).set(place, player);
            return true;
        }
        return false;
    }

    public int checkSmallBoardWinner(int boardIndex) {
        List<Integer> board = fullBoard.get(boardIndex);
        for (List<Integer> position : WINNING_POSITIONS) {
            int a = position.get(0), b = position.get(1), c = position.get(2);
            if (!board.get(a).equals(0) && board.get(a).equals(board.get(b)) && board.get(b).equals(board.get(c))) {
                return board.get(a);
            }
        }
        return board.contains(0) ? 0 : -1;
    }

    public int checkFullBoardWinner() {
        List<Integer> bigBoard = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            bigBoard.add(checkSmallBoardWinner(i));
        }
        for (List<Integer> position : WINNING_POSITIONS) {
            int a = position.get(0), b = position.get(1), c = position.get(2);
            if (!bigBoard.get(a).equals(0) && bigBoard.get(a).equals(bigBoard.get(b)) && bigBoard.get(b).equals(bigBoard.get(c))) {
                return bigBoard.get(a);
            }
        }
        return bigBoard.contains(0) ? 0 : -1;
    }

}
