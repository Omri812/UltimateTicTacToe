package com.example.ultimate_tic_tac_toe.resignDialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.joinDialog.IDialog;

public class ResignDialog extends Dialog implements View.OnClickListener{

    public IResignDialog context;
    public Button yes;
    public Button no;



    public ResignDialog(@NonNull IResignDialog context) {
        super((AppCompatActivity)context);
        this.context = context;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resign_dialog);

        yes = findViewById(R.id.button_yes);
        no = findViewById(R.id.button_no);

        yes.setOnClickListener(this);
        no.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button_yes) {
            // Handle "Yes" click
            context.onDialogYes(); // for example
        }

        dismiss(); // close dialog after a click
    }

}
