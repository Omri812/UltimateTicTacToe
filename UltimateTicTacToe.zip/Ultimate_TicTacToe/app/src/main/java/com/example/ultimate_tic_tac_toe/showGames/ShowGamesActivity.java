package com.example.ultimate_tic_tac_toe.showGames;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.homePage.HomeActivity;
import com.example.ultimate_tic_tac_toe.model.User;

public class ShowGamesActivity extends AppCompatActivity {

    ShowGamesPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_games);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });






        presenter = new ShowGamesPresenter(this);






    }

    public void setRecycler(GameAdapter adapter){
        RecyclerView recyclerView = findViewById(R.id.recyclerview_games);

        //RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);

        recyclerView.setLayoutManager( new LinearLayoutManager(this));

        recyclerView.setAdapter(adapter);

    }

    public void GoBack(View view) {
        setResult(RESULT_OK, new Intent(this, HomeActivity.class));
        finish();
    }

    public void updateGamesText(User user) {
        TextView textView = findViewById(R.id.games_tv_showGames);
        textView.setText("Games: " + user.getGames());

        TextView textView2 = findViewById(R.id.usrnm_tv_showGames);
        textView2.setText("Hello " + user.getUsername());

        TextView textView3 = findViewById(R.id.wins_tv_showGames);
        textView3.setText("Wins: " + user.getWins());

    }
}