package com.example.ultimate_tic_tac_toe.resignScreen;

import android.util.Log;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.auth.FirebaseAuth;

public class ResignScreenPresenter implements Repository.LoadRunningGameListener, Repository.LoadUserListener{


    private ResignScreenActivity view;

    private RunningGame currentRunningGame;

    private User currentUser;

    private int gameCode;

    public ResignScreenPresenter(ResignScreenActivity view) {

        this.view = view;

        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());

        Repository.getInstance().setRunningGameListener(this);
        currentRunningGame = Repository.getInstance().getCurrentRunningGame();

        /*view.updateBoard(currentRunningGame);*/

    }

    @Override
    public void getRunningGame(RunningGame runningGame) {
        currentRunningGame = runningGame;
        gameCode = runningGame.getGameCode();
    }

    @Override
    public void getUser(User user) {
        currentUser = user;
        view.updateBoard(currentRunningGame);
    }

    public void updateUser(GameHistory gameHistory) {
        currentUser.addGameHistory(gameHistory);
        Repository.getInstance().addUser(currentUser);
    }

    public void removeRunningGame() {
        Repository.getInstance().removeRunningGame(currentRunningGame.getGameCode());
    }

    public String getCurrentUserName() {
        return currentUser.getUsername();
    }

    public RunningGame getCurrentRunningGame() {
        return currentRunningGame;
    }

    public String getOtherPlayerName(){
        if(currentUser.getUsername().equals(currentRunningGame.getPlayer1())){
            return currentRunningGame.getPlayer2();
        }
        else{
            return currentRunningGame.getPlayer1();
        }
    }

    public void addGameToUser(String winner) {
        if(winner.equals(currentUser.getUsername())){
            currentUser.addWin();
        }
        currentUser.addGame();
        Repository.getInstance().addUser(currentUser);
    }
}
