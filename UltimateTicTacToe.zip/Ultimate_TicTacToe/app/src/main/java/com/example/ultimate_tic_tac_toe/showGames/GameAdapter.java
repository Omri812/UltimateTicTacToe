package com.example.ultimate_tic_tac_toe.showGames;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.model.GameHistory;

import java.util.ArrayList;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder>{
    private ArrayList<GameHistory> games;

    public GameAdapter(ArrayList<GameHistory> games) {
        this.games = games;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View gameView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycleritem_history, parent, false);
        return new GameViewHolder(gameView);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {
        GameHistory currentGame = games.get(position);
        holder.player1Name.setText(currentGame.getPlayer1Name());
        holder.player2Name.setText(currentGame.getPlayer2Name());
        holder.player1Status.setText(currentGame.getPlayer1Status());
        holder.player2Status.setText(currentGame.getPlayer2Status());
    }

    @Override
    public int getItemCount() {
        return games != null ? games.size() : 0;
    }


    public static class GameViewHolder extends RecyclerView.ViewHolder {

        public TextView player1Name;
        public TextView player2Name;
        public TextView player1Status;
        public TextView player2Status;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);
            player1Name = itemView.findViewById(R.id.textview_u1name);
            player2Name = itemView.findViewById(R.id.textview_u2name);
            player1Status = itemView.findViewById(R.id.textview_u1status);
            player2Status = itemView.findViewById(R.id.textview_u2status);
        }
    }
}