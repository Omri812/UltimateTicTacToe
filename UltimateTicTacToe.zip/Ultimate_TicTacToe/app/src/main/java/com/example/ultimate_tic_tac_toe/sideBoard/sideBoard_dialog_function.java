package com.example.ultimate_tic_tac_toe.sideBoard;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.model.RunningGame;

import java.util.ArrayList;

public class sideBoard_dialog_function extends Dialog {

    Context context;

    RunningGame runningGame;

    private ImageView[] imageViews = {};
    private ImageView minimap;

    int clickedPlaceToView;

    int prevPlaceClickedBoard;

    Boolean isPlaying;

    public sideBoard_dialog_function(@NonNull Context context, RunningGame runningGame, Boolean isPlaying) {
        super(context);
        this.context = context;
        this.runningGame = runningGame;
        prevPlaceClickedBoard = runningGame.getPrevClickedPlace();
        this.isPlaying = isPlaying;

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(c);
        setContentView(R.layout.sideboard_dialog);

        minimap = findViewById(R.id.miniMap_img_sdBrd);


        imageViews = new ImageView[]{
                findViewById(R.id.place0_img_sdBrd),
                findViewById(R.id.place1_img_sdBrd),
                findViewById(R.id.place2_img_sdBrd),
                findViewById(R.id.place3_img_sdBrd),
                findViewById(R.id.place4_img_sdBrd),
                findViewById(R.id.place5_img_sdBrd),
                findViewById(R.id.place6_img_sdBrd),
                findViewById(R.id.place7_img_sdBrd),
                findViewById(R.id.place8_img_sdBrd)
        };

        updateBoardLook();

        for (int i = 0; i < imageViews.length; i++) {
            imageViews[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    checkClicked(view.getId());
                }
            });

        }


    }

    private void updateBoardLook() {

        int[] placeImages = {
                R.drawable.place0, R.drawable.place1, R.drawable.place2,
                R.drawable.place3, R.drawable.place4, R.drawable.place5,
                R.drawable.place6, R.drawable.place7, R.drawable.place8
        };

        minimap.setImageResource(placeImages[clickedPlaceToView]);



        ArrayList<Integer> smallBoard = runningGame.getFullBoard().get(clickedPlaceToView);
        for (int i = 0; i < 9; i++) {
            int status = smallBoard.get(i);
            switch (status) {
                case 1:
                    imageViews[i].setImageResource(R.drawable.blackx);
                    break;
                case 2:
                    imageViews[i].setImageResource(R.drawable.yellowo);
                    break;
                case 0:
                    imageViews[i].setImageResource(R.drawable.nothing);
                    break;
            }
        }


    }

    private void checkClicked(int id) {
        /*Toast.makeText(context,"isPlaying: "+isPlaying,Toast.LENGTH_SHORT).show();*/

        int player = runningGame.getWhichPlayerPlaying();
        if(clickedPlaceToView == prevPlaceClickedBoard && isPlaying){
            int[] placeIds = {
                    R.id.place0_img_sdBrd, R.id.place1_img_sdBrd, R.id.place2_img_sdBrd,
                    R.id.place3_img_sdBrd, R.id.place4_img_sdBrd, R.id.place5_img_sdBrd,
                    R.id.place6_img_sdBrd, R.id.place7_img_sdBrd, R.id.place8_img_sdBrd
            };

            // Find which place was clicked dynamically
            for (int i = 0; i < placeIds.length; i++) {
                if (id == placeIds[i]) {
                    /*runningGame.checkClickedPlace(prevPlaceClickedBoard, i, player);*/
                    if(runningGame.checkClickedPlace(prevPlaceClickedBoard, i, player)){
                        runningGame.setWhichPlayerPlaying(player == 1 ? 2 : 1);
                        runningGame.setPrevClickedPlace(i);
                        Repository.getInstance().addRunningGame(runningGame);

                        /*this.dismiss();*/
                        if (isShowing()) {
                            dismiss();
                        }
                    }


                    break;
                }
            }
        }



    }

    public void setClickedPlaceToView(int clickedPlaceToView) {
        this.clickedPlaceToView = clickedPlaceToView;
    }



}
