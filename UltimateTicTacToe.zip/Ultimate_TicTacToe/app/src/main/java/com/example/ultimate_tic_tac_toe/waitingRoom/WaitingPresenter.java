package com.example.ultimate_tic_tac_toe.waitingRoom;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.util.Objects;
import java.util.Random;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.mainBoard.MainBoardActivity;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.auth.FirebaseAuth;

public class WaitingPresenter implements Repository.LoadUserListener, Repository.LoadRunningGameListener {
    WaitingActivity view;
    User currentUser;
    RunningGame runningGame;
    Boolean isLeader;
    int gameCode;

    public WaitingPresenter(WaitingActivity view, Boolean isLeader){
        this.view = view;
        this.isLeader = isLeader;


        if(isLeader){
            String code = creatingCode();
            view.updateCode(code);
            gameCode = Integer.parseInt(code);
        }


        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());


    }

    public void clickedOnStartGame() {

        if (isLeader && runningGame.getStatus() == 2){

            runningGame.setStatus(3);
            Random random = new Random();
            int randomNumber = random.nextInt(2) + 1;
            runningGame.setWhichPlayerPlaying(randomNumber);
            Repository.getInstance().addRunningGame(runningGame);
        }
    }

    public String creatingCode(){
        Random rand = new Random();
        int randomNumber = rand.nextInt(900000) +100000;
        return String.format("%06d", randomNumber);
    }


    @Override
    public void getUser(User user) {
        currentUser = user;
        if(isLeader){
            view.updatePlayer1Text(currentUser.getUsername(), currentUser.getPicture());
            RunningGame runningGame = new RunningGame(user.getUsername(), gameCode, user.getPicture());
            Repository.getInstance().addRunningGame(runningGame);
            Repository.getInstance().setRunningGameListener(this);
            Repository.getInstance().readRunningGame(gameCode);
        }
        else{
            view.setButtonNotVisible();
            Repository.getInstance().setRunningGameListener(this);
            Repository.getInstance().readRunningGame(gameCode);
        }
    }


    @Override
    public void getRunningGame(RunningGame runningGame) {
        this.runningGame = runningGame;

        if(runningGame.getStatus() == -2){
            view.updateLobby();
            runningGame.setPlayer2_img(null);
            runningGame.setPlayer2(null);
            runningGame.setStatus(1);
            Repository.getInstance().addRunningGame(runningGame);
        }
        if(runningGame.getStatus() == -1){
            Repository.getInstance().removeRunningGame(gameCode);
            view.gameRemoved();
        }
        if(runningGame.getStatus() == 2){
            view.updatePlayer2Text(runningGame);
        }
        if(runningGame.getStatus() == 3){
            view.switchToGameActivity();
        }
    }

    public void setGameCode(int requestCode) {
        this.gameCode = requestCode;
    }

    public void setCancelResult() {
        if(isLeader){
            if(Objects.equals(runningGame.getPlayer2(), "") || runningGame.getPlayer2() == null){
                Repository.getInstance().removeRunningGame(gameCode);
                view.backToHomePage();
            }
            else{
                runningGame.setStatus(-1);
                Repository.getInstance().addRunningGame(runningGame);
                view.backToHomePage();
            }
        }
        else{
            runningGame.setStatus(-2);
            Repository.getInstance().addRunningGame(runningGame);
            view.backToHomePage();
        }
    }
}
