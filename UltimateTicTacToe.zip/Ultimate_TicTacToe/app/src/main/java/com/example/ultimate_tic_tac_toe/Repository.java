package com.example.ultimate_tic_tac_toe;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class Repository {
    private static Repository repository_instance;
    FirebaseDatabase database;

    public RunningGame getCurrentRunningGame() {
        return currentRunningGame;
    }

    RunningGame currentRunningGame;

    public static final String FireBaseLink = "";
    /**
     * You need to put your firebase link here.
     *
     * Read the README file.
     *
     * **/

    private Repository(){
        database = FirebaseDatabase.getInstance(FireBaseLink);
    }
    public static Repository getInstance(){
        if(repository_instance == null){
            repository_instance = new Repository();
        }
        return repository_instance;
    }




    public interface LoadUserListener{
        void getUser(User user);
    }

    LoadUserListener loadUserListener;

    public void setLoadUserListener(LoadUserListener loadUserListener) {
        this.loadUserListener = loadUserListener;
    }


    public interface LoadRunningGamesListener{
        void getRunningGames(ArrayList<RunningGame> runningGames);

    }

    LoadRunningGamesListener runningGamesListener;

    public void setRunningGamesListener(LoadRunningGamesListener runningGamesListener) {
        this.runningGamesListener = runningGamesListener;
    }


    public interface LoadRunningGameListener{
        void getRunningGame(RunningGame runningGame);
    }

    LoadRunningGameListener runningGameListener;

    public void setRunningGameListener(LoadRunningGameListener runningGameListener) {
        this.runningGameListener = runningGameListener;
    }




    public void setUserListener(LoadUserListener userListener) {
        this.loadUserListener = userListener;
    }




    public void addUser(User user){
        DatabaseReference myRef = database.getReference("Users/" +user.getId());
        myRef.setValue(user);

    }

    public void addRunningGame(RunningGame runningGame){
        DatabaseReference myRef = database.getReference("RunningGames/" +runningGame.getGameCode());
        myRef.setValue(runningGame);
    }



    public void readUser(String id){
        DatabaseReference myRef = database.getReference("Users/" +id);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User value = dataSnapshot.getValue(User.class);
                loadUserListener.getUser(value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void readRunningGames() {
        DatabaseReference myRef = database.getReference("RunningGames");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<RunningGame> value = new ArrayList<>();
                for (DataSnapshot db: dataSnapshot.getChildren()) {
                    value.add(db.getValue(RunningGame.class));
                }
                runningGamesListener.getRunningGames(value);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void readRunningGame(int gameCode){
        DatabaseReference myRef = database.getReference("RunningGames/" + gameCode);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    RunningGame runningGame = dataSnapshot.getValue(RunningGame.class);
                    runningGameListener.getRunningGame(runningGame);
                    currentRunningGame = runningGame;
                }
                else {
                    Log.d("Firebase", "readRunningGame(): Game " + gameCode + " does not exist.");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void removeRunningGame(int gameCode) {
        DatabaseReference myRef = database.getReference("RunningGames").child(String.valueOf(gameCode));

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    myRef.removeValue()
                            .addOnSuccessListener(aVoid -> Log.d("Firebase", "Game removed successfully"))
                            .addOnFailureListener(e -> Log.e("Firebase", "Failed to remove game", e));
                } else {
                    Log.d("Firebase", "removeRunningGame(): Game " + gameCode + " does not exist.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "removeRunningGame(): Database error: " + databaseError.getMessage());
            }
        });
    }

    public String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    public Bitmap convertBase64ToBitmap(String base64String) {
        byte[] decodedString = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }


}
