package com.example.ultimate_tic_tac_toe.mainBoard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.MyService;
import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.endScreen.EndActivity;
import com.example.ultimate_tic_tac_toe.model.RunningGame;

import com.example.ultimate_tic_tac_toe.model.User;
import com.example.ultimate_tic_tac_toe.resignDialog.IResignDialog;
import com.example.ultimate_tic_tac_toe.resignDialog.ResignDialog;
import com.example.ultimate_tic_tac_toe.resignScreen.ResignScreenActivity;
import com.example.ultimate_tic_tac_toe.sideBoard.sideBoard_dialog_function;
import com.example.ultimate_tic_tac_toe.waitingRoom.WaitingActivity;

public class MainBoardActivity extends AppCompatActivity implements IResignDialog {


    // Presenter instance
    private MainBoardPresenter presenter;

    // ImageView resource IDs for the main board
    private ImageView[] imageViews = {};

    private TextView playerTurnTv;

    private Boolean clickedOnResign = false;

    private Intent svc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_board);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        svc = new Intent(this, MyService.class);
        startService(svc);



        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

            }
        });


        playerTurnTv = findViewById(R.id.playerTurn_tv_mnBrd);

        imageViews = new ImageView[]{
                findViewById(R.id.place0_img_mnBrd),
                findViewById(R.id.place1_img_mnBrd),
                findViewById(R.id.place2_img_mnBrd),
                findViewById(R.id.place3_img_mnBrd),
                findViewById(R.id.place4_img_mnBrd),
                findViewById(R.id.place5_img_mnBrd),
                findViewById(R.id.place6_img_mnBrd),
                findViewById(R.id.place7_img_mnBrd),
                findViewById(R.id.place8_img_mnBrd)
        };

        for (int i = 0; i < imageViews.length; i++) {
            imageViews[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openDialog(view.getId());
                }
            });

        }



        presenter = new MainBoardPresenter(this, getIntent().getIntExtra("gameCode", 0));



    }

    public Boolean getIsPlaying(RunningGame rg){
        boolean isPlaying;

        if(presenter.getCurrentUser().getUsername().equals(rg.getPlayer1())){
            isPlaying = (rg.getWhichPlayerPlaying() == 1);
        }
        else{
            isPlaying = (rg.getWhichPlayerPlaying() == 2);

        }
        return isPlaying;
    }


    private sideBoard_dialog_function sd;

    private void openDialog(int id) {


        RunningGame rg = presenter.getCurrentRunningGame();

        Boolean isPlaying = getIsPlaying(rg);

        /*if(isPlaying){
            sideBoard_dialog_function sd = new sideBoard_dialog_function(this, rg, isPlaying);

            sd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            sd.setCancelable(true);

            if(id == R.id.place0_img_mnBrd){
                sd.setClickedPlaceToView(0);
            }
            else if (id == R.id.place1_img_mnBrd) {
                sd.setClickedPlaceToView(1);
            }
            else if (id == R.id.place2_img_mnBrd) {
                sd.setClickedPlaceToView(2);
            }
            else if (id == R.id.place3_img_mnBrd) {
                sd.setClickedPlaceToView(3);
            }
            else if (id == R.id.place4_img_mnBrd) {
                sd.setClickedPlaceToView(4);
            }
            else if (id == R.id.place5_img_mnBrd) {
                sd.setClickedPlaceToView(5);
            }
            else if (id == R.id.place6_img_mnBrd) {
                sd.setClickedPlaceToView(6);
            }
            else if (id == R.id.place7_img_mnBrd) {
                sd.setClickedPlaceToView(7);
            }
            else if (id == R.id.place8_img_mnBrd) {
                sd.setClickedPlaceToView(8);
            }

            sd.show();

        }*/

        sd = new sideBoard_dialog_function(this, rg, isPlaying);

        sd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        sd.setCancelable(true);

        if(id == R.id.place0_img_mnBrd){
            sd.setClickedPlaceToView(0);
        }
        else if (id == R.id.place1_img_mnBrd) {
            sd.setClickedPlaceToView(1);
        }
        else if (id == R.id.place2_img_mnBrd) {
            sd.setClickedPlaceToView(2);
        }
        else if (id == R.id.place3_img_mnBrd) {
            sd.setClickedPlaceToView(3);
        }
        else if (id == R.id.place4_img_mnBrd) {
            sd.setClickedPlaceToView(4);
        }
        else if (id == R.id.place5_img_mnBrd) {
            sd.setClickedPlaceToView(5);
        }
        else if (id == R.id.place6_img_mnBrd) {
            sd.setClickedPlaceToView(6);
        }
        else if (id == R.id.place7_img_mnBrd) {
            sd.setClickedPlaceToView(7);
        }
        else if (id == R.id.place8_img_mnBrd) {
            sd.setClickedPlaceToView(8);
        }

        sd.show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            Log.d("test", "MB: onActivityResult() 1: work");
            setResult(RESULT_OK, new Intent(this, WaitingActivity.class));
            finish();
        }
    }

    public void updateBoard(RunningGame runningGame) {



        for (int i = 0; i < 9; i++) {
            int status = runningGame.checkSmallBoardWinner(i);
            imageViews[i].setBackground(null);
            switch (status) {
                case 1:
                    imageViews[i].setImageResource(R.drawable.blackx);
                    break;
                case 2:
                    imageViews[i].setImageResource(R.drawable.yellowo);
                    break;
                case -1:
                    imageViews[i].setImageResource(R.drawable.redtie);
                    break;
                case 0:
                    imageViews[i].setImageResource(R.drawable.nothing);
                    break;
            }
        }

        int prevPlace = runningGame.getPrevClickedPlace();
        imageViews[prevPlace].setBackground(getDrawable(R.drawable.prev_clicked_place_background));


        if(getIsPlaying(runningGame)){
            playerTurnTv.setText("Your Turn");
        }
        else{
            playerTurnTv.setText("Opponent's Turn");
        }

    }


    public void switchToEndGame(RunningGame rg) {


        Intent intent = new Intent(this, EndActivity.class);
        intent.putExtra("gameCode", rg.getGameCode());
        stopService(svc);
        startActivityForResult(intent, 1);



    }


    public void checkEndGame(RunningGame currentRunningGame) {
        int status = currentRunningGame.checkFullBoardWinner();
        if(status == 1 || status == 2 || status == -1){
            currentRunningGame.setStatus(4);
            Repository.getInstance().addRunningGame(currentRunningGame);
        }
    }

    public void whiteFlag(View view) {
        ResignDialog rd = new ResignDialog(this);
        rd.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        rd.setCancelable(false);
        rd.show();
    }

    @Override
    public void onDialogYes() {
        presenter.playerResign();
        clickedOnResign = true;
    }

    @Override
    public void onDialogNo() {

    }

    public void switchToResignScreen(RunningGame rg) {

        Intent intent = new Intent(this, ResignScreenActivity.class);
        intent.putExtra("gameCode", rg.getGameCode());
        if(clickedOnResign){
            intent.putExtra("wonByResign", presenter.getOtherPlayerName());
        }
        else{
            intent.putExtra("wonByResign", presenter.getCurrentUser().getUsername());
        }
        stopService(svc);
        startActivityForResult(intent, 1);
    }

    public void setSymbol(User user, RunningGame currentRunningGame) {
        TextView textView = findViewById(R.id.who_tv_mainB);

        if (user.getUsername().equals(currentRunningGame.getPlayer1())) {
            textView.setText("You are X");
        } else {
            textView.setText("You are O");
        }
    }

    public void closeSmallGame() {
        if (sd != null && sd.isShowing()) {
            sd.dismiss();
        }
    }
}
