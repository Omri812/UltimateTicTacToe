package com.example.ultimate_tic_tac_toe.mainBoard;


import com.example.ultimate_tic_tac_toe.Repository;

import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.auth.FirebaseAuth;


public class MainBoardPresenter implements Repository.LoadRunningGameListener, Repository.LoadUserListener {

    private int gameCode;

    private MainBoardActivity view;

    private RunningGame currentRunningGame;

    private User currentUser;

    public MainBoardPresenter(MainBoardActivity view, int gameCode) {
        this.view = view;
        this.gameCode = gameCode;

        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());

        Repository.getInstance().setRunningGameListener(this);
        currentRunningGame = Repository.getInstance().getCurrentRunningGame();


    }

    @Override
    public void getRunningGame(RunningGame runningGame) {
        currentRunningGame = runningGame;
        if (currentRunningGame.getStatus() == 5) {
            view.switchToResignScreen(currentRunningGame);
        }
        if (currentRunningGame.getStatus() == 4) {
            view.switchToEndGame(currentRunningGame);
        }
        runningGameUpdated();

    }

    private void runningGameUpdated() {
        view.closeSmallGame();
        view.updateBoard(currentRunningGame);
        view.checkEndGame(currentRunningGame);


    }

    public RunningGame getCurrentRunningGame() {
        return currentRunningGame;
    }

    @Override
    public void getUser(User user) {
        currentUser = user;
        view.setSymbol(user, currentRunningGame);
        runningGameUpdated();

    }

    public User getCurrentUser() {
        return currentUser;
    }


    public void playerResign() {
        currentRunningGame.setStatus(5);
        Repository.getInstance().addRunningGame(currentRunningGame);
    }

    public String getOtherPlayerName(){
        if(currentUser.getUsername().equals(currentRunningGame.getPlayer1())){
            return currentRunningGame.getPlayer2();
        }
        else{
            return currentRunningGame.getPlayer1();
        }
    }
}

