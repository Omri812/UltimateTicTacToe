package com.example.ultimate_tic_tac_toe.showGames;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Collections;

public class ShowGamesPresenter implements Repository.LoadUserListener {
    ShowGamesActivity view;
    User currentUser;
    public ShowGamesPresenter(ShowGamesActivity view){
        this.view = view;
        Repository.getInstance().setUserListener(this);
        Repository.getInstance().readUser(FirebaseAuth.getInstance().getUid());


    }

    public void getGamesByUserName(){
        ArrayList<GameHistory> games = currentUser.getGamesHistory();
        if(games != null){
            Collections.reverse(games);
        }

        GameAdapter adapter = new GameAdapter(games);
        view.setRecycler(adapter);
        view.updateGamesText(currentUser);
    }

    @Override
    public void getUser(User user) {


        currentUser = user;

        getGamesByUserName();
    }


}
