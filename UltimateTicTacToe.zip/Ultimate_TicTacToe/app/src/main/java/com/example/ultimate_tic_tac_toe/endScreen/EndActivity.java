package com.example.ultimate_tic_tac_toe.endScreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ultimate_tic_tac_toe.R;
import com.example.ultimate_tic_tac_toe.mainBoard.MainBoardActivity;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.RunningGame;
import com.example.ultimate_tic_tac_toe.model.User;


public class EndActivity extends AppCompatActivity {

    EndPresenter presenter;

    private ImageView[] imageViews = {};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_end);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {

            }
        });


        int gameCode = getIntent().getIntExtra("gameCode", 0);

        imageViews = new ImageView[]{
                findViewById(R.id.place0_img_end),
                findViewById(R.id.place1_img_end),
                findViewById(R.id.place2_img_end),
                findViewById(R.id.place3_img_end),
                findViewById(R.id.place4_img_end),
                findViewById(R.id.place5_img_end),
                findViewById(R.id.place6_img_end),
                findViewById(R.id.place7_img_end),
                findViewById(R.id.place8_img_end)
        };

        presenter = new EndPresenter(this, gameCode);


    }

    public void backToHome(View view) {

        addGameToHistory();
        presenter.removeRunningGame();
        Intent intent = new Intent(this, MainBoardActivity.class);
        setResult(RESULT_OK, intent);
        finish();

    }

    public void updateBoard(RunningGame runningGame) {



        for (int i = 0; i < 9; i++) {
            int status = runningGame.checkSmallBoardWinner(i);
            imageViews[i].setBackground(null);
            switch (status) {
                case 1:
                    imageViews[i].setImageResource(R.drawable.blackx);
                    break;
                case 2:
                    imageViews[i].setImageResource(R.drawable.yellowo);
                    break;
                case -1:
                    imageViews[i].setImageResource(R.drawable.redtie);
                    break;
                case 0:
                    imageViews[i].setImageResource(R.drawable.nothing);
                    break;
            }
        }

       /* TextView winner = findViewById(R.id.winner_tv_end);
        int whoWon = runningGame.checkFullBoardWinner();

        String currentUser = presenter.getCurrentUserName();
        String winnerText = "";

        if (whoWon == 1) {
            winnerText = runningGame.getPlayer1().equals(currentUser) ? "You Won" : runningGame.getPlayer1() + " Won";
        } else if (whoWon == 2) {
            winnerText = runningGame.getPlayer2().equals(currentUser) ? "You Won" : runningGame.getPlayer2() + " Won";
        } else if (whoWon == -1) {
            winnerText = "Tie";
        }

        winner.setText(winnerText);*/

        TextView winner = findViewById(R.id.winner_tv_end);
        int whoWon = runningGame.checkFullBoardWinner();
        if(whoWon == 1){
            winner.setText(runningGame.getPlayer1() + " Won");
        }
        else if(whoWon == 2){
            winner.setText(runningGame.getPlayer2() + " Won");
        }
        else if(whoWon == -1){
            winner.setText("Tie");
        }

    }


    public void addGameToHistory() {

        GameHistory gameHistory;

        String username = presenter.getCurrentUserName();
        String player1 = presenter.getCurrentRunningGame().getPlayer1();
        String player2 = presenter.getCurrentRunningGame().getPlayer2();
        int winner = presenter.getCurrentRunningGame().checkFullBoardWinner();
        String player1Status;
        String player2Status;

        if(winner == -1){
            player1Status = "tie";
            player2Status = "tie";
        }
        else{
            player1Status = winner == 1 ? "won" : "lost";
            player2Status = winner == 2 ? "won" : "lost";
        }


        if(username.equals(player1)){
            gameHistory = new GameHistory(player1, player2, player1Status,  player2Status);
        }
        else{
            gameHistory = new GameHistory(player2, player1, player2Status,  player1Status);
        }
        presenter.updateUser(gameHistory);
    }

}