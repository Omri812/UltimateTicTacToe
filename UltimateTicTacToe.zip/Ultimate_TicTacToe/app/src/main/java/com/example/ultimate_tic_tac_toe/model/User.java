package com.example.ultimate_tic_tac_toe.model;

import java.util.ArrayList;

public class User {




    private String username;

    private String id;

    private ArrayList<GameHistory> gamesHistory;

    private String picture;

    private int wins = 0;

    private int games = 0;

    public User() {
    }

    public User(String username, String id, ArrayList<GameHistory> games, String picture) {

        this.username = username;

        this.id = id;
        this.gamesHistory = games;

        this.picture = picture;

        this.wins = 0;
        this.games = 0;

    }

    public String getUsername() {
        return username;
    }
    public ArrayList<GameHistory> getGamesHistory() {
        return gamesHistory;
    }
    public String getId() {
        return id;
    }
    public String getPicture() {
        return picture;
    }
    public int getWins() {
        return wins;
    }
    public int getGames() {
        return games;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public void setGamesHistory(ArrayList<GameHistory> gamesHistory) {
        this.gamesHistory = gamesHistory;
    }
    public void setWins(int wins) {

        this.wins = wins;
    }
    public void setGames(int games) {
        this.games = games;
    }

    public void addWin() {
        wins++;
    }
    public void addGame() {
        games++;
    }

    public void addGameHistory(GameHistory game) {

        if (gamesHistory == null) {
            gamesHistory = new ArrayList<>();
        }

        gamesHistory.add(game);
    }


}
