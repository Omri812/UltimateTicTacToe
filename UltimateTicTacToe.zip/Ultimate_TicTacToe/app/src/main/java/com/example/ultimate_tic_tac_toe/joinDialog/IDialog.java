package com.example.ultimate_tic_tac_toe.joinDialog;

public interface IDialog {
    void getCode(int code);
}
