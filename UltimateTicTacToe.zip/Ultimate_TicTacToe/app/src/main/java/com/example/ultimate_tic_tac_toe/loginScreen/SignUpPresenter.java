package com.example.ultimate_tic_tac_toe.loginScreen;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.ultimate_tic_tac_toe.Repository;
import com.example.ultimate_tic_tac_toe.model.GameHistory;
import com.example.ultimate_tic_tac_toe.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.io.InputStream;
import java.util.ArrayList;

public class SignUpPresenter {
    SignUpActivity view;
    Bitmap bitmap;

    private FirebaseAuth mAuth;


    public SignUpPresenter(SignUpActivity view) {
        this.view = view;
        mAuth = FirebaseAuth.getInstance();

    }

    public void checkSignUp(String gmail, String username, String password) {
        if(!gmail.isEmpty() && !password.isEmpty() && !username.isEmpty() && bitmap != null) {
            mAuth.createUserWithEmailAndPassword(gmail, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Successfully signed up, go to home screen
                                ArrayList<GameHistory> games = new ArrayList<GameHistory>();
                                User user = new User( username, mAuth.getUid(), games, Repository.getInstance().convertBitmapToBase64(bitmap));
                                Repository.getInstance().addUser(user);

                                view.SignUpWorked();
                            }

                        }
                    });
        }
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ContentResolver contentResolver = view.getContentResolver();
            InputStream inputStream = contentResolver.openInputStream(uri);
            return BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setBitmap(Uri selectedImageUri) {
        bitmap = getBitmapFromUri(selectedImageUri);
    }

}
